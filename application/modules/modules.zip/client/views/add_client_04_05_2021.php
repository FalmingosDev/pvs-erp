<style>
	.table-condensed{
		width: 185px !important;
	}
/*    .ui-datepicker-year
{
    display:none;   
}*/
</style>
<section class="main-wrapper">
          <div class="container">
            <div class="row">
                <div class="col-md-12">
                  <?php echo clientTabs(); ?>
                  <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-client" role="tabpanel" aria-labelledby="nav-home-tab">
                      <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h1>Client Master</h1>
                                <div class="wrapper-box">
                                    <?php echo validation_errors(); ?>
                                    <?php echo form_open( base_url( 'client/add' ), array( 'id' => 'clientform', 'class' => 'form-horizontal form-hori-border' ) ); ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Client Name</label>
                                                    <div class="col-sm-9">
                                                      <input type="text" name="client_name" class="form-control form-control-sm" id="" placeholder="Client name" value="<?php echo set_value('client_name'); ?>">
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Address Line 1</label>
                                                    <div class="col-sm-9">
                                                      <input type="text" name="address_line_1" class="form-control form-control-sm" id="" placeholder="Address Line 1" value="<?php echo set_value('address_line_1'); ?>">
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                        <label for="colFormLabelSm" class="col-sm-4 col-form-label col-form-label-sm">Agreement Start Date</label>
                                                        <div class="col-sm-8">
                                                          <input type="date" data-date-format="dd-mm-yyyy" class="form-control form-control-sm" id="" placeholder="" name="agreemnt_start_date" value="<?php echo set_value('agreemnt_start_date'); ?>">
                                                        </div>
                                                  </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                        <label for="colFormLabelSm" class="col-sm-4 col-form-label col-form-label-sm">Agreement End Date</label>
                                                        <div class="col-sm-8">
                                                          <input type="date" data-date-format="dd-mm-yyyy" class="form-control form-control-sm" id="" name="agreemnt_end_date" value="<?php echo set_value('agreemnt_end_date'); ?>">
                                                        </div>
                                                      </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Address Line 2</label>
                                                    <div class="col-sm-9">
                                                      <input type="text" class="form-control form-control-sm" id="" name="address_line_2" placeholder="Address Line 2" value="<?php echo set_value('address_line_2'); ?>">
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Type</label>
                                                    <div class="col-sm-9">

                                                    	<?php 
														//$options = array($type->industry_type_id);
														$attributes = array('class' => 'form-control form-control-sm', 'id' => 'type_id');
														$selected = (set_value('type_id')) ? set_value('type_id') : '';
														echo form_dropdown('type_id', $type, $selected, $attributes);
													?>
                                                        <!-- <select class="form-control form-control-sm" id="type_id" name="type_id">
                                                            <?php                                       
                                                                //foreach($type as $type) 
                                                                {  
                                                                ?>
                                                                <option value="<?PHP echo $type->industry_type_id;?>"><?PHP echo $type->industry_type_name; ?></option>
                                                                 <?php
                                                                }
                                                                ?>  
                                                        </select> -->
                                                        <p>( Industry Type )</p>
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Address Line 3</label>
                                                    <div class="col-sm-9">
                                                      <input type="text" name="address_line_3" class="form-control form-control-sm" id="" placeholder="Address Line 3" value="<?php echo set_value('address_line_3'); ?>">
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Rating</label>
                                                    <div class="col-sm-9">

                                                    	<?php 
															//$options = array($type->industry_type_id);
															$attributes = array('class' => 'form-control form-control-sm', 'id' => 'rating_id');
															$selected = (set_value('rating_id')) ? set_value('rating_id') : '';
															echo form_dropdown('rating_id', $rating, $selected, $attributes);
														?>
                                                        <!-- <select id="rating_id" name="rating_id" class="form-control form-control-sm">
                                                            <?php                                       
                                                            //foreach($rating as $rating) 
                                                            {  
                                                            ?>
                                                            <option value="<?PHP echo $rating->rating_id;?>"><?PHP echo $rating->rating_short_name; ?></option>
                                                             <?php
                                                            }
                                                                ?>
                                                        </select> -->
                                                        <p>( Buisness Potential )</p>
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">State</label>
                                                    <div class="col-sm-9">
                                                        <select id="state_id" name="state_id" class="form-control form-control-sm">
                                                        	<option value="">Select state</option>
                                                        	<?php                                       
															foreach($state as $state) 
															{  
															?>
				                                            <option value="<?PHP echo $state->state_id;?>"><?PHP echo $state->state_name; ?></option>
					                                         <?php
															}
																?>
                                                        </select>
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Location</label>
                                                    <div class="col-sm-9">
                                                        <label class="cont-radio-location"><input type="radio" name="location" value="M">Multi Location</label>
                                                        <label class="cont-radio-location"><input type="radio" name="location" value="S">Single Location</label>                                                        
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">City</label>
                                                    <div class="col-sm-9">
                                                      <select id="city_id" name="city_id" class="form-control form-control-sm">
                                        	
                                        			  </select>
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Tel Nos</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control form-control-sm" id="" name="tel_nos" placeholder="Tel Nos">
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Pincode </label>
                                                    <div class="col-sm-9">
                                                      <input type="text" class="form-control form-control-sm" id="" name="pincode" placeholder="Pincode">
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Fax </label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control form-control-sm" id="" name="fax" placeholder="Fax">
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Foundation Day </label>
                                                    <div class="col-sm-9">
                                                      <input type="date" class="form-control form-control-sm" id="" placeholder="" name="foundation_day">
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Email </label>
                                                    <div class="col-sm-9">
                                                        <input type="email" class="form-control form-control-sm" id="" name="client_email" placeholder="Email">
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">MW Type </label>
                                                    <div class="col-sm-9">
                                                      <select id="mw_type_id" name="mw_type_id" class="form-control form-control-sm">
                                                        	<?php                                       
															foreach($mw_type as $mw_type) 
															{  
															?>
				                                            <option value="<?PHP echo $mw_type->mw_type_id;?>"><?PHP echo $mw_type->mw_type_name; ?></option>
					                                         <?php
															}
																?>  
                                                        </select>
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Website </label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control form-control-sm" name="website" placeholder="Website">
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Source  </label>
                                                    <div class="col-sm-9">
                                                      <select id="source_id" name="source_id" class="form-control form-control-sm">
                                                        	<?php                                       
															foreach($source as $source) 
															{  
															?>
				                                            <option value="<?PHP echo $source->source_id;?>"><?PHP echo $source->source_name; ?></option>
					                                         <?php
															}
																?>  
                                                        </select>
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom-row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Contract Status </label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="contract_status_id" name="contract_status_id">
                                                            <?php                                       
															foreach($contract_status as $cs) 
															{  
															?>
				                                            <option value="<?PHP echo $cs->contract_status_id;?>"><?php echo $cs->contract_status_name; ?></option>
					                                         <?php
															}
																?>  
                                                        </select>
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Source Reference  </label>
                                                    <div class="col-sm-9">
                                                        <textarea class="form-control form-control-sm" name="source_ref" id="source_ref"></textarea>
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="row mt-2">
                                        	<h3 class="cl-h3">Client Contact Details</h3>
                                            <div class="col-md-10">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered">
                                                      <thead>
                                                        <tr>
                                                          <th scope="col">Name</th>
                                                          <th scope="col">Designation</th>
                                                          <th scope="col">Contact No</th>
                                                          <th scope="col">Email</th>
                                                            <th scope="col">Birthday</th>
                                                          <th scope="col">Anniversary</th>
                                                        </tr>
                                                      </thead>
                                                      <tbody id="tab_body">
                                                        <!-- <tr>
                                                          <td><input type="text" class="form-control form-control-sm" id="" placeholder=""></td>
                                                          <td><input type="text" class="form-control form-control-sm" id="" placeholder=""></td>
                                                          <td><input type="tel" class="form-control form-control-sm" id="" placeholder=""></td>
                                                            <td><input type="email" class="form-control form-control-sm" id="" placeholder=""></td>
                                                          <td><input type="date" class="form-control form-control-sm" id="" placeholder=""></td>
                                                          <td><input type="date" class="form-control form-control-sm" id="" placeholder=""></td>
                                                        </tr> -->
                                                      </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" class="add-cont-btn" id="add_more_btn">Add</button>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">Remarks</label>
                                                    <div class="col-sm-9">
                                                        <textarea class="form-control form-control-sm" name="remarks" id="remarks"></textarea>
                                                    </div>
                                                  </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label for="colFormLabelSm" class="col-sm-3 col-form-label col-form-label-sm">&nbsp;</label>
                                                    <div class="col-sm-9">
                                                        <div class="form-actions">
                                                            <button type="submit" class="btn btn-success">Save</button>
                                                        </div>
                                                    </div>
                                                  </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                
                </div>  
            </div>
          </div>
        
      </section>

      <script>

      	 $(document).ready(function(){
    	       $('.date-picker').datepicker();
         	   addnewclient();      
                
                $('.date-picker').datepicker({ 
                    autoclose: true,
                    format: 'mm-dd'
                    // minViewMode: "months",
                    // minViewMode: "years",
                    //endDate: new Date()
                });
                
                	 });

        $('body').on('hover', '.nav-item.dropdown', function() {
            $(this).find('.dropdown-toggle').dropdown('toggle');
        });

         $("#state_id").change(() => {
	        var state_id = $("#state_id").val();
	        populatecity(state_id);
    	})

    function populatecity(state_id){
        //alert(state_id);
       var result='';
        //var csrfName = $('.PVS_ERP_csrf').attr('name');

    $.ajax({
        type: 'POST',   
        url: '<?php echo base_url('client/city_list'); ?>',
        data: {state_id: state_id,<?= $this->security->get_csrf_token_name(); ?>: $("[name='<?= $this->security->get_csrf_token_name(); ?>']").val()},
        dataType: 'json',
        encode: true,
    })
    //ajax response
    .done(function(data){
        $("[name='<?= $this->security->get_csrf_token_name(); ?>']").val(data.newHash);
        if(data.status){            
            result +='<option value="">Select City</option>';

            $.each(data.city_list,function(key,value){
            	//value(value.city_name);
                result +='<option value="'+value.city_id+'">'+value.city_name+'</option>';
            });
        }
        else{
            result +='<option value="">No city selected</option>';
        }
        $("#city_id").html(result);
       // $("#city_id").selectpicker("refresh");
    
    })
    
    .fail(function(data){
        // show the any errors
        console.log(data);
    });
}

  function addnewclient(){
        var resulthtml='';
        resulthtml +='<tr width="100%" class="add_more_contact" style="">';
        resulthtml +='<td><input type="text" name="name[]" class="form-control form-control-sm" id="name0"></td>';
        resulthtml +='<td><input type="text" name="designation[]" class="form-control form-control-sm" id="designation0"></td>';
        resulthtml +='<td><input type="text" name="contact_no[]" class="form-control form-control-sm" id="contact_no0"></td>';
        resulthtml +='<td><input type="text" name="email[]" class="form-control form-control-sm" id="email0"></td>';
        resulthtml +='<td><input type="text" name="birthday[]" class="form-control form-control-sm date-picker" id="birthday0"></td>';
        resulthtml +='<td><input type="text" name="anniversary[]" class="form-control form-control-sm date-picker" id="anniversary0"></td>';
        //resulthtml +='<td>&nbsp;</td>';
        resulthtml +='</tr>';
        $("#tab_body").html(resulthtml);

        //  $("#birthday0").datepicker({
        // format: 'dd/mm',
        // todayHighlight: true,
        // autoclose: true
        // });

        //  $("#anniversary0").datepicker({
        // format: 'dd/mm',
        // todayHighlight: true,
        // autoclose: true
        // });
    }

    var cnt =0;
    $("#add_more_btn").click(function () 
    {
        cnt++;
        var resulthtml='';
        resulthtml +='<tr class="add_more_contact" id="add_more_contact'+cnt+'" style="width:100%;">';
        resulthtml +='<td><input type="text" name="name[]" class="form-control form-control-sm" id="name'+cnt+'"></td>';
        resulthtml +='<td><input type="text" name="designation[]" class="form-control form-control-sm" id="designation'+cnt+'"></td>';
        resulthtml +='<td><input type="text" name="contact_no[]" class="form-control form-control-sm" id="contact_no'+cnt+'"></td>';
        resulthtml +='<td><input type="text" name="email[]" class="form-control form-control-sm" id="email'+cnt+'"></td>';
        resulthtml +='<td><input type="text" name="birthday[]" class="form-control form-control-sm date-picker" id="birthday'+cnt+'"></td>';
        resulthtml +='<td><input type="text" name="anniversary[]" class="form-control form-control-sm date-picker" id="anniversary'+cnt+'"></td>';
        resulthtml +='<td style="border: none;"><button type="button" class="but-btn" style:"background: transparent;border: none;margin-top: -10px;" value="delete" id="del_div'+cnt+'" onclick="delchild('+cnt+')"><i class="fa fa-trash-o fn-1" aria-hidden="true"></i></button></td>';
        resulthtml +='</tr>';
        $("#tab_body").append(resulthtml);

        $("#birthday"+cnt).datepicker({
        format: 'mm-dd',
        todayHighlight: true,
        autoclose: true
        });

        $("#anniversary"+cnt).datepicker({
        format: 'mm-dd',
        todayHighlight: true,
        autoclose: true
        });

         //focus_blur();
        $('.del_div').on('click',function()
        {
            //alert(1);
            $(this).parents('.add_more_contact').remove();
        });
    });

     function delchild(abc)
        {
            //alert(abc);
            $("#add_more_contact"+abc).remove();
        }

      </script>

         <script type="text/javascript">
        // $(function() {
        //     $('.date-picker').datepicker( {
        //     changeMonth: true,
        //     changeYear: true,
        //     showButtonPanel: true,
        //     dateFormat: 'dd MM',
        //     onClose: function(dateText, inst) { 
        //         $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
        //     }
        //     });
        // });

  
    </script>
<!DOCTYPE html>
<html>
<head>
<title>PVS ERP</title>
</head>

<body>
    <table style="width: 100%;">
        <tr>
            <td style="width: 100%;font-size: 60px;font-weight: bold;">
               Premier Vigilance Security Pvt.Ltd
            </td>
        </tr>
         <tr>
            <td style="width: 100%;">
               <table style="width: 100%;">
                    <tr>
                        <td style="width: 85%;font-size: 40px;">
                            Regd office : 4B Orient Road, Kolkata - 700017
                        </td>
                        <td style="width: 15%;font-size: 40px;">
                            Arr No : ......
                        </td>
                    </tr>
               </table>
            </td>
        </tr>
        <tr>
            <td style="width: 100%;">
                <table style="width: 100%;">
                    <tr>
                    <td style="width: 100%;font-size: 35px;text-align: right;">
                        Unit Code : ......
                    </td>
                </tr> 
                </table>
            </td>
        </tr>
        <tr>
             <td style="width: 100%;">
                <table style="width: 100%;">
                   <tr>
                        <td style="width: 60%;font-size: 50px;font-weight: bold;text-align: right;">
                            Arrear Salary
                        </td>
                       <td style="width: 5%;"></td>
                        <td style="width: 35%;font-size: 45px;font-weight: bold;">
                            Unit : Kotak Mahindra Bank Ltd. Agra, Kuberpur, U.P.
                        </td>
                    </tr> 
                </table>
             </td>
        </tr>
        <tr>
            <td style="width: 100%;border-bottom: 2px solid #000;">
                <table style="width: 100%;">
                    <tr>
                        <td style="width: 30%;font-size: 40px;font-weight: bold;">Month Processed July</td>
                        <td style="width: 10%;font-size: 35px;font-weight: bold;">2021</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">Period:</td>
                        <td style="width: 10%;font-size: 35px;">01/09/2020</td>
                        <td style="width: 2%;font-size: 35px;text-align: center;">to</td> 
                        <td style="width: 10%;font-size: 35px;">01/09/2020</td>
                        <td style="width: 30%;"></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td style="width: 100%;">
                <table style="width: 100%;">
                    <tr>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Sno</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Emp No</th>
                        <th style="width: 12%;font-size: 35px;font-weight: bold;">Employee<br> Name</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Duties</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Basic</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Gross</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">PF</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">ESI</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">P/T</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">TDedt</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Net Pay</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Signature</th>  
                    </tr>
                    <tr>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 12%;font-size: 35px;font-weight: bold;">Father's<br> Name</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">OT</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;">Or</th>    
                    </tr>
                    <tr>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 12%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">Designation</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">+</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">&nbsp;</th>
                        <th style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;">Thumb<br> Impression</th>    
                    </tr>
                    <tr>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">1</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">110527</td>
                        <td style="width: 12%;font-size: 35px;font-weight: bold;">Mukesh Babu</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">6.00</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">400</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">600</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">48.00</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">5.00</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">0.00</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">53</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">447</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>    
                    </tr>
                    <tr>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;border-top: 1px solid #000;border-left: 1px solid #000;border-right: 1px solid #000;text-align: center;">Salary</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">SW.greetam Nath</td>
                        <td style="width: 12%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>    
                    </tr>
                    <tr>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;border-left: 1px solid #000;border-right: 1px solid #000;text-align: center;">Month</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">Security Guard</td>
                        <td style="width: 12%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">New</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">Old</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>    
                    </tr>
                    <tr>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;border-left: 1px solid #000;border-right: 1px solid #000;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 12%;font-size: 35px;font-weight: bold;">Basic</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">9000</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">7000</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">Uan:</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">1234567</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>    
                    </tr>
                    <tr>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;border-left: 1px solid #000;border-right: 1px solid #000;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;">PF No : 12345</td>
                        <td style="width: 12%;font-size: 35px;">Gross</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">10000</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">7000</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">Bank Nm:</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">SBI</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>    
                    </tr>
                    <tr>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;border-left: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;">30/09/2020</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">ESI No : 12345</td>
                        <td style="width: 12%;font-size: 35px;font-weight: bold;">OT</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">10000</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">8000</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">A/C No:</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">123456</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;">&nbsp;</td>    
                    </tr>
                    <br>
                    <tr>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">&nbsp;</td>  
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">Unit Salary total</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">&nbsp;</td>
                        <td style="width: 12%;font-size: 35px;font-weight: bold;border-top: 1px solid #000;padding-top: 10px;">6.00</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">48.00</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">5.00</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">0.00</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">53</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-top: 1px solid #000;padding-top: 10px;">547</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;border-top: 1px solid #000;padding-top: 10px;">&nbsp;</td>    
                    </tr>  
                    <tr>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>  
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 12%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;padding-bottom: 10px;">1.50</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;border-bottom: 1px solid #000;padding-bottom: 10px;">&nbsp;</td>
                        <td style="width: 8%;font-size: 35px;font-weight: bold;border-bottom: 1px solid #000;padding-top: 10px;">&nbsp;</td>    
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>
